"use client";

import { useMemo, useState, useTransition } from "react";
import {
  hitungUlangNilaiMapel,
  resetUjianSiswa,
  hitungUlangNilaiMapelAdmin,
  // overrideNilai / overrideNilaiAdmin SENGAJA tidak diimpor lagi — nilai
  // di Rekap Penilaian sekarang fixed/read-only, tidak boleh diubah
  // manual oleh siapa pun. Server Action-nya sendiri sudah dimatikan
  // total di src/app/admin/nilai/actions.ts, jadi menghapus tombol
  // "Ubah" di sini bukan satu-satunya penjaga — ini lapisan UI-nya saja.
} from "@/app/admin/nilai/actions";
import BadgeJenjang from "@/components/admin/BadgeJenjang";
import type { Jenjang } from "@/lib/jenjang";
import { unduhExcelRekapNilai, type KelasRekapNilai } from "@/lib/excel";
import { muatAnalisisButir } from "@/app/admin/statistik/actions";
import AnalisisButir from "@/components/admin/Statistik/AnalisisButir";
import type { AnalisisButirSoal } from "@/types";

export interface SoalRingkas {
  id: string;
  urutan: number;
  skor: number;
}

export interface BarisNilai {
  siswaId: string;
  nama: string;
  username: string;
  kelasNama: string;
  submitted: boolean;
  totalSkor: number | null;
  isOverride: boolean;
  detailJsonb: Record<string, number>;
}

function fmtSkor(n: number | null) {
  if (n === null) return "—";
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

/**
 * Jumlah benar/salah per siswa, dihitung dari `detailJsonb` (skor yang
 * didapat per soal) dibandingkan skor maksimal soal itu.
 *
 * "Benar" berarti mendapat skor PENUH untuk soal itu (toleransi 0.0001
 * untuk pembulatan angka desimal) — bukan sekadar "dapat skor lebih dari
 * nol". Untuk tipe soal dengan skor sebagian (pilihan ganda kompleks,
 * benar-salah bertingkat), siswa yang benar separuh opsi tetap dihitung
 * "salah" di sini, karena rekap ini merangkum satu angka per soal, dan
 * jawaban yang tidak sepenuhnya benar bukan jawaban yang benar.
 *
 * Soal yang TIDAK ADA sama sekali di `detailJsonb` (tidak dijawab siswa)
 * dihitung sebagai salah, bukan diabaikan — soal yang dilewati tetap
 * soal yang gagal dijawab, dan jumlah benar+salah harus selalu berjumlah
 * sama dengan jumlah soal di mapel ini supaya rekapnya bisa dipercaya.
 */
function hitungBenarSalah(
  detailJsonb: Record<string, number>,
  soalList: SoalRingkas[]
): { benar: number; salah: number } {
  let benar = 0;
  for (const s of soalList) {
    const didapat = detailJsonb[s.id];
    if (didapat !== undefined && didapat >= s.skor - 0.0001) {
      benar++;
    }
  }
  return { benar, salah: soalList.length - benar };
}

function unduhCsv(
  mapelNama: string,
  soalList: SoalRingkas[],
  rows: BarisNilai[]
) {
  const header = [
    "Nama",
    "Username",
    "Kelas",
    "Status",
    ...soalList.map((s) => `Soal ${s.urutan}`),
    "Total Skor",
    "Override Manual",
  ];

  const escape = (v: string | number) => {
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };

  const lines = [header.map(escape).join(",")];

  for (const row of rows) {
    const kolomSoal = soalList.map((s) =>
      row.detailJsonb[s.id] !== undefined ? fmtSkor(row.detailJsonb[s.id]) : ""
    );
    lines.push(
      [
        row.nama,
        row.username,
        row.kelasNama,
        row.submitted ? "Sudah submit" : "Belum submit",
        ...kolomSoal,
        fmtSkor(row.totalSkor),
        row.isOverride ? "Ya" : "Tidak",
      ]
        .map(escape)
        .join(",")
    );
  }

  const csv = "\uFEFF" + lines.join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `nilai-${mapelNama.replace(/\s+/g, "_").toLowerCase()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function BarisSiswa({
  row,
  mapelId,
  jenjang,
  soalList,
}: {
  row: BarisNilai;
  mapelId: string;
  jenjang: Jenjang;
  soalList: SoalRingkas[];
}) {
  const [showDetail, setShowDetail] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  // Reset ujian menghapus jawaban & nilai secara permanen, jadi butuh
  // konfirmasi. Dibuat sebagai dua tombol di tempat (bukan window.confirm)
  // supaya konsisten dengan pola AkunAksiButtons.tsx, dan supaya teks
  // konfirmasinya bisa menyebut nama siswa yang benar-benar terdampak.
  const [konfirmReset, setKonfirmReset] = useState(false);
  const [pendingReset, startReset] = useTransition();

  function reset() {
    setErrorMsg(null);
    startReset(async () => {
      const hasil = await resetUjianSiswa({
        jenjang,
        mapelId,
        siswaId: row.siswaId,
      });
      setKonfirmReset(false);
      if (hasil.error) setErrorMsg(hasil.error);
    });
  }

  return (
    <>
      <tr className="border-b border-ink/5 last:border-0">
        <td className="py-2.5 pl-3 pr-3">
          <p className="text-sm text-ink">{row.nama}</p>
          <p className="text-xs text-ink/40">
            {row.username} · {row.kelasNama}
          </p>
        </td>
        <td className="py-2.5 pr-3">
          {row.submitted ? (
            <span className="rounded-full bg-ok/10 px-2 py-0.5 text-xs font-medium text-ok">
              Sudah submit
            </span>
          ) : (
            <span className="rounded-full bg-ink/5 px-2 py-0.5 text-xs font-medium text-ink/40">
              Belum submit
            </span>
          )}
        </td>
        <td className="py-2.5 pr-3">
          <div className="flex items-center gap-2">
            <span className="font-serif text-sm text-ink">
              {fmtSkor(row.totalSkor)}
            </span>
            {row.isOverride && (
              <span className="rounded-full bg-gold/15 px-1.5 py-0.5 text-[10px] font-medium text-gold-dark">
                override
              </span>
            )}
          </div>
          {errorMsg && <p className="mt-1 text-xs text-danger">{errorMsg}</p>}
        </td>
        <td className="py-2.5 pr-3 text-right">
          {row.submitted && (
            <div className="flex flex-wrap items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowDetail((v) => !v)}
                className="text-xs text-ink/50 hover:text-ink"
              >
                {showDetail ? "Sembunyikan" : "Detail"}
              </button>

              {konfirmReset ? (
                <span className="flex items-center gap-1.5 rounded-lg bg-red-50 px-2 py-1 ring-1 ring-red-200">
                  <span className="text-[0.7rem] font-semibold text-red-700">
                    Hapus jawaban {row.nama}?
                  </span>
                  <button
                    type="button"
                    disabled={pendingReset}
                    onClick={reset}
                    className="rounded bg-danger px-2 py-0.5 text-[0.7rem] font-bold text-white disabled:opacity-50"
                  >
                    {pendingReset ? "…" : "Ya, reset"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setKonfirmReset(false)}
                    className="text-[0.7rem] font-semibold text-slate-500 hover:text-ink"
                  >
                    Batal
                  </button>
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => setKonfirmReset(true)}
                  className="rounded-lg border border-red-200 px-2 py-1 text-[0.7rem] font-bold text-danger transition-colors hover:bg-red-50"
                >
                  <i className="fas fa-rotate-left mr-1" aria-hidden />
                  Reset ujian
                </button>
              )}
            </div>
          )}
        </td>
      </tr>
      {showDetail && (
        <tr className="border-b border-ink/5 bg-paper-dark/30 last:border-0">
          <td colSpan={4} className="px-3 py-3">
            <div className="flex flex-wrap gap-2">
              {soalList.map((s) => (
                <span
                  key={s.id}
                  className="rounded border border-ink/10 bg-white px-2 py-1 text-xs text-ink/70"
                >
                  Soal {s.urutan}:{" "}
                  <span className="font-medium text-ink">
                    {row.detailJsonb[s.id] !== undefined
                      ? fmtSkor(row.detailJsonb[s.id])
                      : "—"}
                  </span>
                  <span className="text-ink/40"> / {fmtSkor(s.skor)}</span>
                </span>
              ))}
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

export default function NilaiTable({
  mapelId,
  mapelNama,
  eventNama,
  tahunAjaran,
  jenjang,
  isAdmin,
  soalList,
  rows,
}: {
  mapelId: string;
  mapelNama: string;
  /** Nama kegiatan (event) tempat mapel ini berada — dipakai di kop rekap
   *  Excel: "PAS Ganjil (7.1)". */
  eventNama: string;
  /** "2026/2027" — dihitung SEKALI di halaman pemanggil dari tanggal
   *  mulai kegiatan (lihat src/lib/tahun-ajaran.ts), bukan di sini, supaya
   *  aturan "tahun ajaran mulai Juli" hanya hidup di satu tempat. */
  tahunAjaran: string;
  /** Database jenjang mana baris-baris ini berasal — dipakai aksi reset. */
  jenjang: Jenjang;
  /** true kalau yang membuka adalah admin (guru.is_admin) — menentukan
   *  apakah override/hitung ulang lewat jalur cookie biasa (guru, RLS)
   *  atau jalur service_role (admin, lintas jenjang). Dioper eksplisit
   *  dari halaman pemanggil (src/app/admin/nilai/page.tsx), BUKAN dibaca
   *  ulang di sini — tabel ini tidak tahu apa-apa soal sesi login. */
  isAdmin: boolean;
  soalList: SoalRingkas[];
  rows: BarisNilai[];
}) {
  const [pendingRecompute, startRecompute] = useTransition();
  const [recomputeMsg, setRecomputeMsg] = useState<string | null>(null);
  const [mengunduh, setMengunduh] = useState(false);
  const [pesanUnduh, setPesanUnduh] = useState<string | null>(null);

  /**
   * Filter kelas — mapel bisa ditarget ke beberapa kelas sekaligus
   * (mis. semua kelas 7), dan sebelum ini seluruh siswa dari semua kelas
   * itu selalu tercampur jadi satu tabel panjang. Guru yang cuma perlu
   * merekap satu kelas untuk diserahkan ke wali kelasnya harus menyisir
   * sendiri baris mana milik kelas mana.
   *
   * "" berarti "Semua Kelas" — bukan berarti dicampur begitu saja: baik
   * tampilan di layar maupun file yang diunduh tetap MENGELOMPOKKAN per
   * kelas (lihat `kelasUntukUnduhan` di bawah), cuma menampilkan/mengunduh
   * semuanya sekaligus alih-alih satu per satu.
   */
  const [kelasFilter, setKelasFilter] = useState("");

  const daftarKelas = useMemo(
    () =>
      Array.from(new Set(rows.map((r) => r.kelasNama))).sort((a, b) =>
        a.localeCompare(b, "id")
      ),
    [rows]
  );

  const rowsTampil = useMemo(
    () =>
      kelasFilter ? rows.filter((r) => r.kelasNama === kelasFilter) : rows,
    [rows, kelasFilter]
  );

  function hitungUlang() {
    setRecomputeMsg(null);
    startRecompute(async () => {
      const result = isAdmin
        ? await hitungUlangNilaiMapelAdmin({ jenjang, mapelId })
        : await hitungUlangNilaiMapel(mapelId);
      setRecomputeMsg(
        result.error ?? "Nilai berhasil dihitung ulang untuk semua siswa yang sudah submit."
      );
    });
  }

  async function unduhRekap() {
    setMengunduh(true);
    setPesanUnduh(null);
    try {
      // Dikelompokkan per kelas TERLEPAS dari kelasFilter tunggal/semua —
      // satu sheet per kelas selalu, sesuai urutan `daftarKelas` yang
      // sudah terurut. Kalau kelasFilter terisi, hasilnya otomatis cuma
      // satu sheet karena `rowsTampil` sudah tersaring duluan.
      const kelasTerlibat = kelasFilter ? [kelasFilter] : daftarKelas;

      const perKelas: KelasRekapNilai[] = kelasTerlibat.map((kNama) => ({
        kelasNama: kNama,
        siswa: rowsTampil
          .filter((r) => r.kelasNama === kNama)
          .map((r) => {
            const { benar, salah } = hitungBenarSalah(
              r.detailJsonb,
              soalList
            );
            return {
              nama: r.nama,
              submitted: r.submitted,
              totalSkor: r.totalSkor,
              isOverride: r.isOverride,
              jumlahBenar: benar,
              jumlahSalah: salah,
            };
          }),
      }));

      // Sheet "Analisis Butir" ikut ditambahkan ke file yang sama kalau
      // datanya tersedia. Kegagalan memuatnya (mis. migrasi 0012 belum
      // dijalankan di project ini) TIDAK boleh menggagalkan unduhan
      // rekap nilainya — guru tetap mendapat file per kelas, plus
      // penjelasan kenapa sheet analisisnya tidak ada.
      let analisisButir: AnalisisButirSoal[] | undefined;
      const hasilAnalisis = await muatAnalisisButir(jenjang, mapelId);
      if (hasilAnalisis.ok) {
        if (hasilAnalisis.data.some((d) => d.jumlah_peserta > 0)) {
          analisisButir = hasilAnalisis.data;
        }
      } else {
        setPesanUnduh(
          `Rekap nilai terunduh, tetapi sheet Analisis Butir dilewati: ${hasilAnalisis.error}`
        );
      }

      await unduhExcelRekapNilai({
        mapelNama,
        eventNama,
        tahunAjaran,
        perKelas,
        analisisButir,
      });
    } catch (e) {
      setPesanUnduh(
        e instanceof Error
          ? `Gagal menyiapkan file Excel: ${e.message}`
          : "Gagal menyiapkan file Excel."
      );
    } finally {
      setMengunduh(false);
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <BadgeJenjang jenjang={jenjang} />

          {daftarKelas.length > 1 && (
            <select
              value={kelasFilter}
              onChange={(e) => setKelasFilter(e.target.value)}
              aria-label="Saring berdasarkan kelas"
              className="cursor-pointer rounded-md border border-ink/15 bg-white px-2.5 py-1.5 text-xs font-medium text-ink outline-none focus:border-gold"
            >
              <option value="">Semua Kelas</option>
              {daftarKelas.map((k) => (
                <option key={k} value={k}>
                  Kelas {k}
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            disabled={pendingRecompute}
            onClick={hitungUlang}
            className="rounded-md border border-ink/15 bg-white px-3 py-1.5 text-xs font-medium text-ink transition-colors hover:border-gold disabled:opacity-50"
          >
            {pendingRecompute ? "Menghitung ulang…" : "Hitung Ulang Nilai"}
          </button>

          {/*
            Tombol utama: rekap Excel rapi dengan kop sekolah, sesuai yang
            diminta guru. Export CSV detail per-soal tetap ada di
            sebelahnya — bukan dihapus — karena isinya lebih rinci
            (skor tiap butir soal) dan masih berguna untuk audit atau
            impor ke sistem lain; ini bukan file yang cocok dicetak dan
            diserahkan ke wali kelas.
          */}
          <button
            type="button"
            disabled={mengunduh || rowsTampil.length === 0}
            onClick={unduhRekap}
            className="rounded-md bg-ok px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-ok/90 disabled:opacity-50"
          >
            <i
              className={`fas ${mengunduh ? "fa-circle-notch fa-spin" : "fa-file-excel"} mr-1.5`}
              aria-hidden
            />
            {mengunduh
              ? "Menyiapkan…"
              : kelasFilter
                ? `Unduh Rekap Kelas ${kelasFilter}`
                : "Unduh Rekap Nilai (Excel)"}
          </button>

          <button
            type="button"
            onClick={() => unduhCsv(mapelNama, soalList, rowsTampil)}
            className="rounded-md border border-ink/15 bg-white px-3 py-1.5 text-xs font-medium text-ink transition-colors hover:border-gold"
          >
            Export CSV Detail
          </button>
        </div>
        {recomputeMsg && (
          <p className="text-xs text-ink/60">{recomputeMsg}</p>
        )}
        {pesanUnduh && <p className="text-xs text-danger">{pesanUnduh}</p>}
      </div>

      <div className="overflow-x-auto rounded-lg border border-ink/10 bg-white">
        <table className="w-full min-w-[560px] text-left">
          <thead>
            <tr className="border-b border-ink/10 text-xs uppercase tracking-wide text-ink/40">
              <th className="px-3 py-2.5 font-medium">Siswa</th>
              <th className="px-3 py-2.5 font-medium">Status</th>
              <th className="px-3 py-2.5 font-medium">Nilai</th>
              <th className="px-3 py-2.5"></th>
            </tr>
          </thead>
          <tbody>
            {rowsTampil.map((row) => (
              <BarisSiswa
                key={row.siswaId}
                row={row}
                mapelId={mapelId}
                jenjang={jenjang}
                soalList={soalList}
              />
            ))}
          </tbody>
        </table>
      </div>

      {rowsTampil.length === 0 && (
        <p className="mt-3 text-center text-xs text-ink/40">
          Tidak ada siswa di kelas ini.
        </p>
      )}

      {/* Analisis butir dihitung per MAPEL (semua kelas yang ditarget),
          bukan per kelas yang sedang disaring di atas. */}
      <div className="mt-6 rounded-lg border border-ink/10 bg-white p-4">
        <AnalisisButir
          mapelId={mapelId}
          jenjang={jenjang}
          mapelNama={mapelNama}
          eventNama={eventNama}
          tahunAjaran={tahunAjaran}
        />
      </div>
    </div>
  );
}