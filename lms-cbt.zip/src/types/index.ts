export type Role = "admin" | "siswa";

export type TipeSoal =
  | "pilgan_biasa"
  | "pilgan_kompleks"
  | "uraian_singkat"
  | "benar_salah"
  | "multi_benar_salah"
  | "menjodohkan";

export interface Kelas {
  id: string;
  tingkat: 7 | 8 | 9;
  nama: string; // "7.1", "8.3", dst
}

export interface Siswa {
  id: string;
  auth_id: string;
  nama: string;
  kelas_id: string;
  username: string;
  created_at: string;
}

export interface Guru {
  id: string;
  auth_id: string;
  nama: string;
  created_at: string;
}

export type JenisEvent =
  | "asesmen_akhir"
  | "kuis_harian"
  | "assignment"
  | "forum";

export interface Event {
  id: string;
  nama: string;
  tgl_mulai: string;
  tgl_selesai: string;
  kelas_utama: 7 | 8 | 9;
  jenis: JenisEvent;
  ditutup_at: string | null;
}

export interface Mapel {
  id: string;
  event_id: string;
  nama: string;
  waktu_mulai: string;
  waktu_selesai: string;
  /** Lama pengerjaan per siswa dalam menit, dihitung sejak dia menekan
   *  "Mulai Ujian" — bukan sejak waktu_mulai. `null` berarti siswa bisa
   *  mengerjakan sampai waktu_selesai (perilaku lama, sebelum kolom ini
   *  ada). Lihat penjelasan panjang di src/app/admin/event/actions.ts. */
  durasi_menit: number | null;
}

export interface MapelKelas {
  mapel_id: string;
  kelas_id: string;
}

export interface Soal {
  id: string;
  mapel_id: string;
  tipe: TipeSoal;
  urutan: number;
  skor: number;
  konten_jsonb: Record<string, unknown>;
  gambar_url: string | null;
}

/**
 * Bentuk baris yang dikembalikan RPC `get_soal_untuk_siswa` — sama seperti
 * `Soal` tapi tanpa `mapel_id` (tidak perlu, siswa sudah tahu dari konteks
 * halaman) dan `konten_jsonb`-nya sudah di-strip field kunci jawaban oleh
 * fungsi database (lihat 0006_soal_siswa_rpc.sql). Jangan pernah perlakukan
 * `konten_jsonb` di sini sebagai kalau berisi field kunci — memang tidak.
 */
export interface SoalSiswa {
  id: string;
  tipe: TipeSoal;
  urutan: number;
  skor: number;
  konten_jsonb: Record<string, unknown>;
  gambar_url: string | null;
}

export interface JawabanSiswaRow {
  siswa_id: string;
  mapel_id: string;
  jawaban_jsonb: Record<string, unknown>;
  submitted_at: string | null;
  updated_at: string;
}

/**
 * Baris tabel `nilai` — hasil koreksi otomatis (Sesi 5, lihat
 * 0007_scoring.sql). `detail_jsonb` berbentuk { [soal_id]: skor_didapat }.
 * `is_override` true kalau guru pernah menimpa `total_skor` manual lewat
 * /admin/nilai (lihat `overrideNilai` action) — dibedakan dari hasil murni
 * koreksi otomatis supaya UI bisa menandainya.
 */
export interface NilaiRow {
  siswa_id: string;
  mapel_id: string;
  total_skor: number;
  detail_jsonb: Record<string, number>;
  is_override: boolean;
  dihitung_at: string;
}

/** Baris hasil RPC `get_statistik_mapel()`, dipakai di /admin/statistik. */
export interface StatistikMapel {
  mapel_id: string;
  mapel_nama: string;
  event_id: string;
  event_nama: string;
  waktu_mulai: string;
  waktu_selesai: string;
  jumlah_target: number;
  jumlah_submit: number;
  skor_maksimal: number;
  rata_rata: number | null;
  skor_min: number | null;
  skor_max: number | null;
}

/** Baris hasil RPC `get_distribusi_nilai(p_mapel_id)`. */
export interface DistribusiNilai {
  rentang: string;
  jumlah: number;
}

/**
 * Baris tabel `log_aktivitas` (Sesi 9, lihat 0009_log_aktivitas.sql untuk
 * penjelasan lengkap kapan trigger DB vs pemanggilan manual dipakai).
 * `guru_id` bisa null kalau baris guru yang bersangkutan sudah dihapus —
 * pakai `detail_jsonb.oleh_nama` (snapshot nama, selalu ada) untuk
 * ditampilkan, jangan cuma mengandalkan join ke `guru`.
 */
export interface LogAktivitas {
  id: string;
  guru_id: string | null;
  aksi: string;
  entitas: string;
  entitas_id: string | null;
  detail_jsonb: Record<string, unknown>;
  created_at: string;
}

// ---------------------------------------------------------------------------
// Tahap 4 — tugas (event.jenis = 'assignment'). Lihat 0019_tugas.sql.
// ---------------------------------------------------------------------------

/**
 * Baris tabel `tugas`. Sejajar dengan `Mapel` di mesin ujian: punya jadwal
 * sendiri (`dibuka_at`/`tenggat`) dan kelas target sendiri (`tugas_kelas`),
 * TIDAK mewarisi tanggal event induknya.
 *
 * `minta_teks` / `minta_berkas`: apa yang diminta dari siswa. Minimal satu
 * harus true (dijaga constraint `tugas_minta_sesuatu`). Keduanya boleh true
 * sekaligus — mis. "tulis ringkasannya di kolom, lalu unggah foto hasil
 * percobaanmu".
 */
export interface Tugas {
  id: string;
  event_id: string;
  judul: string;
  deskripsi: string;
  dibuka_at: string;
  tenggat: string;
  skor_maksimal: number;
  izinkan_terlambat: boolean;
  minta_teks: boolean;
  minta_berkas: boolean;
  created_at: string;
}

export interface TugasKelas {
  tugas_id: string;
  kelas_id: string;
}

/**
 * Baris tabel `pengumpulan_tugas` — gabungan "jawaban" dan "nilai" untuk
 * satu siswa di satu tugas.
 *
 * DUA null YANG ARTINYA SANGAT BERBEDA, dan keduanya sering tertukar:
 *
 *   submitted_at === null  -> masih DRAF. Siswa sudah mengetik sesuatu
 *     (atau mengunggah berkas) tapi belum menekan "Kumpulkan". Guru tidak
 *     menghitungnya sebagai sudah mengumpulkan.
 *
 *   nilai === null         -> BELUM DINILAI. Beda dari `nilai === 0`, yang
 *     berarti guru sudah membaca dan memberi nol. UI wajib membedakan
 *     keduanya.
 *
 * Tidak ada kolom `terlambat`: dihitung dari `submitted_at > tugas.tenggat`
 * saat ditampilkan, supaya guru yang memperpanjang tenggat otomatis
 * memaafkan semua yang terlanjur lewat. Alasannya panjang, ada di kepala
 * migrasi 0019.
 */
export interface PengumpulanTugas {
  tugas_id: string;
  siswa_id: string;
  teks: string;
  berkas_path: string | null;
  berkas_nama: string | null;
  berkas_ukuran: number | null;
  submitted_at: string | null;
  updated_at: string;
  nilai: number | null;
  catatan_guru: string | null;
  dinilai_at: string | null;
  dinilai_by: string | null;
}

// ---------------------------------------------------------------------------
// Tahap 5 — forum diskusi (event.jenis = 'forum'). Lihat 0020_forum.sql.
// ---------------------------------------------------------------------------

/**
 * Baris tabel `forum_topik`. Jadwal buka/tutupnya berlaku untuk SEMUA
 * kelas yang ditautkan lewat `forum_kelas` — beda dari `Tugas`, yang
 * jadwalnya per tugas tapi tetap satu untuk semua kelas targetnya juga
 * (di titik ini keduanya sama); yang beda dari tugas adalah biasanya cuma
 * ADA SATU forum_topik yang relevan per event (lihat penjelasan di kepala
 * 0020_forum.sql soal kenapa halaman admin langsung ke [kelasId] tanpa
 * [topikId]).
 */
export interface ForumTopik {
  id: string;
  event_id: string;
  dibuka_at: string;
  ditutup_at: string;
  created_at: string;
}

export interface ForumKelas {
  forum_topik_id: string;
  kelas_id: string;
}

export type JenisIsiForumPesan = "teks" | "sticker" | "emoticon";

/**
 * Baris tabel `forum_pesan` — satu bubble chat.
 *
 * Persis SATU dari `siswa_id`/`guru_id` yang terisi (constraint
 * `forum_pesan_satu_pengirim`), dan itulah yang dipakai UI untuk memilih
 * gaya bubble (kiri/kanan, warna). `kelas_id` dipilih eksplisit saat
 * insert, tidak disimpulkan dari `siswa_id` — lihat penjelasan panjang di
 * kepala 0020_forum.sql ("KENAPA CHAT PER KELAS TERPISAH").
 */
export interface ForumPesan {
  id: string;
  forum_topik_id: string;
  kelas_id: string;
  siswa_id: string | null;
  guru_id: string | null;
  isi: string;
  jenis_isi: JenisIsiForumPesan;
  /** Toggle, bukan akumulasi — lihat `forum.ts` (`POIN_BONUS_PER_KLIK`) dan
   *  komentar kolom ini di 0020_forum.sql. */
  bonus_diberikan: boolean;
  created_at: string;
}

/**
 * Baris tabel `forum_poin` — agregat, dijaga sinkron oleh trigger di
 * `forum_pesan` (0020_forum.sql bagian 3), TIDAK PERNAH ditulis langsung
 * dari Server Action.
 *
 * Siswa yang belum pernah mengirim pesan bertipe teks di ruang ini TIDAK
 * punya baris di sini sama sekali — bukan baris dengan angka 0. Tampilan
 * papan poin kelas WAJIB memakai daftar siswa kelas sebagai sumber baris
 * (kiri), lalu menempeli angka dari sini (kanan) kalau ada, supaya siswa
 * yang belum pernah bicara sekalipun tetap terlihat di papan dengan
 * "0 pesan" — bukan hilang begitu saja dari daftar.
 */
export interface ForumPoin {
  forum_topik_id: string;
  kelas_id: string;
  siswa_id: string;
  poin_pesan: number;
  poin_bonus: number;
  /** `poin_pesan + poin_bonus`, generated column di database — lihat
   *  `hitungPoinTotal()` di forum.ts untuk versi TypeScript-nya (dipakai
   *  saat menghitung ulang di sisi klien sebelum refresh selesai). */
  total: number;
}
